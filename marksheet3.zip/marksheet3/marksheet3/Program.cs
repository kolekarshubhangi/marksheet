﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


    namespace marksheet3
    {
        class Program
        {
            abstract public class Marks
            {
                abstract public void Mvc(int subject1);
                abstract public void AspDotNet(int subject2);
                abstract public void UI(int subject3);
                abstract public void CSharp(int subject4);
                abstract public void Java(int subject5);
                abstract public void Sql(int subject6);
            }

            interface ISubject
            {
                int TotalMarks(int subject1, int subject2, int subject3, int subject4, int subject5, int subject6);
                float TotalPercentage(int totalMarks);
            }

            public class StudentInfo : Marks, ISubject
            {
                public string Name { get; set; }
                public int RollNo { get; set; }
                public string Qualification { get; set; }
                public string Course { get; set; }

                public void Student1(string name, int rollno, string qualification, string course)
                {
                     Name = name;
                    RollNo = rollno;
                    Qualification = qualification;
                    Course = course;

                    Console.WriteLine($"||Name: {Name}                                                  ||");
                    Console.WriteLine($"||Roll No: {RollNo}                                              ||");
                    Console.WriteLine($" ||Qualification: {Qualification}                                      || ");
                    Console.WriteLine($"||Course: {Course}                                                   ||");
                }

                public override void Mvc(int subject1)
                {
                    Console.WriteLine($"||MVC: {subject1}                     | Grade: {GetGrade(subject1)}              ||");
                }

                public override void AspDotNet(int subject2)
                {
                    Console.WriteLine($"||AspDotNet: {subject2}                |       Grade: {GetGrade(subject2)}                   ||");
                }

                public override void UI(int subject3)
                {
                    Console.WriteLine($"||UI: {subject3}                        |     Grade: {GetGrade(subject3)}             ||");
                }
           
                public override void CSharp(int subject4)
                {
                    Console.WriteLine($"||CSharp: {subject4}                     |          Grade: {GetGrade(subject4)}        ||");
                }

                public override void Java(int subject5)
                {
                    Console.WriteLine($"||Java: {subject5}                       | Grade: {GetGrade(subject5)}                ||");
                }

                public override void Sql(int subject6)
                {
                    Console.WriteLine($"||SQL: {subject6}                       |             Grade: {GetGrade(subject6)}                ||");
                }

                public int TotalMarks(int subject1, int subject2, int subject3, int subject4, int subject5, int subject6)
                {
                    return subject1 + subject2 + subject3 + subject4 + subject5 + subject6;
                }

                public float TotalPercentage(int totalMarks)
                {
                    return (totalMarks / 6.0f);
                }

                // Changed to public for accessibility
                public string GetGrade(int marks)
                {
                    if (marks <= 35)
                    {
                        return "F";
                    }
                    else if (marks > 35 && marks < 40)
                    {
                        return "D";
                    }
                    else if (marks >= 40 && marks < 60)
                    {
                        return "C";
                    }
                    else if (marks >= 60 && marks < 70)
                    {
                        return "B";
                    }
                    else if (marks >= 70 && marks < 80)
                    {
                        return "B+";
                    }
                    else if (marks >= 80 && marks < 89)
                    {
                        return "A";
                    }
                    else
                    {
                        return "A+";
                    }
                }
            }

            static void Main(string[] args)
            {
                string name;
                int rollno;
                string qualification;
                string course;
                int subject1, subject2, subject3, subject4, subject5, subject6;

                Console.WriteLine("Enter the student name:");
                name = Console.ReadLine();
                Console.WriteLine("Enter the Student Id:");
                rollno = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter the qualification of student:");
                qualification = Console.ReadLine();
                Console.WriteLine("Enter the course name:");
                course = Console.ReadLine();

                Console.WriteLine("Enter the marks of the student:");
                Console.WriteLine("MVC:");
                subject1 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("AspDotNet:");
                subject2 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("UI:");
                subject3 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("CSharp:");
                subject4 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Java:");
                subject5 = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("SQL:");
                subject6 = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("*********************************************************************************");

                Console.WriteLine("------------------------------------IT-PRENEUR-----------------------------------");

                Console.WriteLine("*********************************************************************************");
                StudentInfo s1 = new StudentInfo();
                s1.Student1(name, rollno, qualification, course);                              
                Console.WriteLine("---------------------------------------------------------------------------------");
                Console.WriteLine("||        Subjectname         ||         Marks            ||        Grade       ||");
                Console.WriteLine("---------------------------------------------------------------------------------");

                s1.Mvc(subject1);
                s1.AspDotNet(subject2);
                s1.UI(subject3);
                s1.CSharp(subject4);
                s1.Java(subject5);
                s1.Sql(subject6);

                int totalMarks = s1.TotalMarks(subject1, subject2, subject3, subject4, subject5, subject6);
                Console.WriteLine("---------------------------------------------------------------------------------");
                Console.WriteLine("||        Total Marks:                             ||  " + totalMarks + "                                    ||");

                Console.WriteLine("---------------------------------------------------------------------------------");
                float percentage = s1.TotalPercentage(totalMarks);
                Console.WriteLine("||      Total Percentage:                         || " + percentage + "                                ||");
                Console.WriteLine("---------------------------------------------------------------------------------");

                string grade = s1.GetGrade((int)percentage);
                Console.WriteLine("||          Grade:                                   || " + grade + "                                    || ");
                Console.WriteLine("---------------------------------------------------------------------------------");

                Console.ReadLine();
            }
        }
    }
